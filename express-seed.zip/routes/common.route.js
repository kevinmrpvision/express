

var common_router = function(app){

    app.get('/login', function (req, res) {
  		res.send('Hello in login')
	})

    //other routes..
}
module.exports = common_router;