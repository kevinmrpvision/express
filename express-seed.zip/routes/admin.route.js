

var admin_router = function(app){
	const prefix = '/admin/';
    app.get(prefix + 'dashboard', function (req, res) {
  		res.send('Hello in dashboard Admin')
	})

    //other routes..
}
module.exports = admin_router;