var trim_middleware = function(app){
	app.use(function (req, res, next) {
  		console.log('Request:', req)
  		next()
	})
}
module.exports = trim_middleware;