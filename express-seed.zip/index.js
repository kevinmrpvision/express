const express = require('express')
var app = express()

/*
* Middleware
*/
var middleware = require('./middlewares/middleware')
/*
* Routes
*/
//require('./routes/route')(app)
app.get('/login',middleware.add_filter, function (req, res) {
  		res.send('Hello in login')
})
app.get('/',function (req, res) {
  		res.send('Hello in login')
})
/*
* Server
*/
app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})